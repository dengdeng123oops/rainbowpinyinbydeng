const TONE_MAP: Record<string, string> = {
  'ā': 'a', 'á': 'a', 'ǎ': 'a', 'à': 'a',
  'ō': 'o', 'ó': 'o', 'ǒ': 'o', 'ò': 'o',
  'ē': 'e', 'é': 'e', 'ě': 'e', 'è': 'e',
  'ī': 'i', 'í': 'i', 'ǐ': 'i', 'ì': 'i',
  'ū': 'u', 'ú': 'u', 'ǔ': 'u', 'ù': 'u',
  'ǖ': 'ü', 'ǘ': 'ü', 'ǚ': 'ü', 'ǜ': 'ü',
  'ü': 'ü', 'v': 'ü'
};

const VOWELS_BY_TONE: Record<string, string[]> = {
  a: ['a', 'ā', 'á', 'ǎ', 'à'],
  o: ['o', 'ō', 'ó', 'ǒ', 'ò'],
  e: ['e', 'ē', 'é', 'ě', 'è'],
  i: ['i', 'ī', 'í', 'ǐ', 'ì'],
  u: ['u', 'ū', 'ú', 'ǔ', 'ù'],
  v: ['ü', 'ǖ', 'ǘ', 'ǚ', 'ǜ'],
  'ü': ['ü', 'ǖ', 'ǘ', 'ǚ', 'ǜ'],
};

/**
 * 去除拼音中的声调，还原为基本英文字母
 */
export function stripTone(pinyin: string): string {
  if (!pinyin) return '';
  return pinyin.split('').map(char => TONE_MAP[char] || char).join('');
}

/**
 * 根据拼音标注规则，获取应该加声调的字母索引
 */
export function getToneMarkerIndex(cleanPinyin: string): number {
  const lowercase = cleanPinyin.toLowerCase();
  
  // 1. 若有 a，则标在 a 上
  const indexA = lowercase.indexOf('a');
  if (indexA !== -1) return indexA;
  
  // 2. 若无 a 但有 o 或 e，则标在 o 或 e 上
  const indexO = lowercase.indexOf('o');
  if (indexO !== -1) return indexO;
  
  const indexE = lowercase.indexOf('e');
  if (indexE !== -1) return indexE;
  
  // 3. 若有 ui 或 iu，标在最后一个字母上
  const indexUI = lowercase.indexOf('ui');
  if (indexUI !== -1) return indexUI + 1;
  
  const indexIU = lowercase.indexOf('iu');
  if (indexIU !== -1) return indexIU + 1;
  
  // 4. 若无以上情况，则标在单个元音 i, u, ü/v 上
  for (let i = 0; i < lowercase.length; i++) {
    const char = lowercase[i];
    if (char === 'i' || char === 'u' || char === 'ü' || char === 'v') {
      return i;
    }
  }
  
  return -1;
}

/**
 * 获取拼音的声调数值 (1-一生, 2-二声, 3-三声, 4-四声, 0-轻声)
 */
export function getCharTone(pinyin: string): number {
  if (!pinyin) return 0;
  if (/[āōēīūǖ]/.test(pinyin)) return 1;
  if (/[áóéíúǘ]/.test(pinyin)) return 2;
  if (/[ǎǒěǐǔǚ]/.test(pinyin)) return 3;
  if (/[àòèìùǜ]/.test(pinyin)) return 4;
  return 0; // 无声调标记，即轻声
}

/**
 * 转换拼音字符串为指定的声调类型
 */
export function replaceTone(pinyinStr: string, targetTone: number): string {
  const clean = stripTone(pinyinStr);
  const index = getToneMarkerIndex(clean);
  if (index === -1) return pinyinStr;
  
  const charToReplace = clean[index];
  const charLower = charToReplace.toLowerCase();
  const tonedList = VOWELS_BY_TONE[charLower];
  
  if (!tonedList) return pinyinStr;
  
  const tonedChar = tonedList[targetTone] || charToReplace;
  
  // 保持原有的大小写
  const finalChar = charToReplace === charToReplace.toUpperCase() ? tonedChar.toUpperCase() : tonedChar;
  
  return clean.substring(0, index) + finalChar + clean.substring(index + 1);
}

/**
 * 获取声调的名称
 */
export function getToneName(tone: number): string {
  switch (tone) {
    case 1: return '阴平 (一声)';
    case 2: return '阳平 (二声)';
    case 3: return '上声 (三声)';
    case 4: return '去声 (四声)';
    default: return '轻声';
  }
}

/**
 * 判断一个字符是否是汉字
 */
export function isChineseChar(char: string): boolean {
  return /[\u4e00-\u9fa5]/.test(char);
}

/**
 * 将普通英文字形 a、g 替换为符合《汉语拼音方案》标准手写规范的单层 ɑ (\u0251) 和 ɡ (\u0261)
 */
export function formatPinyinForDisplay(pinyinStr: string): string {
  if (!pinyinStr) return '';
  // 避免替换为特殊的 IPA 字符 ɑ 和 ɡ。因为特殊的 IPA 字体可能在部分设备上由于字体不支持导致发生降级 fallback，
  // 产生糟糕的高度不一致或拼音和声调剥离、字母 eng/ing 错位等问题。
  // 我们在 css 中设置的 --font-pinyin（华文细黑、STXihei、Comfortaa、Century Gothic、Andika 等）已经天然内置了
  // 极具美感的手写单层 a 和 g 的ASCII字形。直接加载标准字符即可展现完美的汉字拼音印刷排版。
  return pinyinStr;
}

