import fs from 'fs';
import path from 'path';

async function download() {
  const url = 'https://db.onlinewebfonts.com/t/3d6ca7a544a86f9ee5bcca5fe90209ab.woff2';
  const dest = path.resolve('src/assets/fonts/STXihei.woff2');
  console.log(`Downloading font from ${url} to ${dest}...`);
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    const buffer = await res.arrayBuffer();
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, Buffer.from(buffer));
    console.log('Download complete!');
  } catch (err) {
    console.error('Error downloading:', err);
    process.exit(1);
  }
}

download();
