export interface PinyinWordItem {
  id: string;          // 唯一标识符
  origin: string;      // 原始单字 (如 '中' 或 '，')
  pinyin: string;      // 当前拼音 (如 'zhōng')
  tone: number;        // 声调类型: 1-一声, 2-二声, 3-三声, 4-四声, 0-轻声
  isWord: boolean;     // 是否是汉字 (非标点、英文字符等)
  isNewline: boolean;  // 是否是换行符
  alternatives: string[]; // 所有的多音字拼音选项 (如 ['de', 'dé', 'děi'])
}

export interface PresetItem {
  title: string;
  category: string;
  content: string;
}
