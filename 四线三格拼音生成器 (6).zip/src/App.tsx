import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { pinyin } from 'pinyin-pro';
import { 
  Sparkles, 
  RotateCcw, 
  Settings2, 
  Grid3X3, 
  Palette, 
  Trash2,
  Info,
  Layers
} from 'lucide-react';

import { PinyinWordItem } from './types';
import { 
  getCharTone, 
  replaceTone, 
  getToneName, 
  isChineseChar,
  formatPinyinForDisplay
} from './utils/pinyinUtils';

import PinyinCard from './components/PinyinCard';
import CopyMenu from './components/CopyMenu';

const TONE_HEX_COLORS: Record<number, string> = {
  1: '#10B981', // 一声: 翡翠绿 (emerald-500)
  2: '#EF4444', // 二声: 胭脂红 (rose-500)
  3: '#3B82F6', // 三声: 霁蓝 (blue-500)
  4: '#171717', // 四声: 玄黑 (stone-950)
  0: '#9CA3AF', // 轻声: 苍灰 (gray-400)
};

const LINE_COLORS = {
  red: {
    outer: 'rgba(239, 68, 68, 0.45)',
    inner: 'rgba(239, 68, 68, 0.25)',
  },
  blue: {
    outer: 'rgba(59, 130, 246, 0.5)',
    inner: 'rgba(59, 130, 246, 0.3)',
  },
  green: {
    outer: 'rgba(16, 185, 129, 0.5)',
    inner: 'rgba(16, 185, 129, 0.3)',
  },
  slate: {
    outer: 'rgba(120, 113, 108, 0.45)',
    inner: 'rgba(120, 113, 108, 0.25)',
  }
};

const getPinyinFontSize = (len: number) => {
  if (len <= 3) return 28;
  if (len === 4) return 25;
  if (len === 5) return 22;
  return 18;
};

export default function App() {
  const [inputText, setInputText] = useState('床前明月光，疑是地上霜。');
  const [resultItems, setResultItems] = useState<PinyinWordItem[]>([]);
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  
  // 教学系统偏好配置
  const [layoutMode, setLayoutMode] = useState<'cards' | 'continuous'>('continuous');
  const [gridStyle, setGridStyle] = useState<'mi' | 'tian' | 'kou'>('mi');
  const [lineColor, setLineColor] = useState<'red' | 'blue' | 'green' | 'slate'>('red');
  const [autoGenerate, setAutoGenerate] = useState(true);

  const containerRef = useRef<HTMLDivElement>(null);

  // 一字一音生成逻辑
  const generateAllPinyin = () => {
    if (!inputText.trim()) {
      setResultItems([]);
      setSelectedCardId(null);
      return;
    }

    const lines = inputText.split('\n');
    const items: PinyinWordItem[] = [];

    lines.forEach((line, lineIndex) => {
      if (line === '') {
        items.push({
          id: `newline-${lineIndex}`,
          origin: '\n',
          pinyin: '',
          tone: 0,
          isWord: false,
          isNewline: true,
          alternatives: [],
        });
        return;
      }

      // 利用 pinyin-pro 将全行按字并置
      const rawList = pinyin(line, { type: 'all' }) as any[];

      rawList.forEach((charItem, charIndex) => {
        const charStr = charItem.origin || '';
        const isWord = isChineseChar(charStr);

        let alternatives: string[] = [];
        if (isWord) {
          // 查找多音字的所有可能拼音
          const alts = pinyin(charStr, { multiple: true, type: 'array' }) as string[];
          alternatives = Array.from(new Set(alts));
        }

        const pinyinVal = charItem.pinyin || '';
        const initialTone = getCharTone(pinyinVal);

        items.push({
          id: `${lineIndex}-${charIndex}-${charStr}`,
          origin: charStr,
          pinyin: pinyinVal,
          tone: initialTone,
          isWord: isWord,
          isNewline: false,
          alternatives: alternatives,
        });
      });

      // 不是最后一行则添加换行符
      if (lineIndex < lines.length - 1) {
        items.push({
          id: `newline-${lineIndex}`,
          origin: '\n',
          pinyin: '',
          tone: 0,
          isWord: false,
          isNewline: true,
          alternatives: [],
        });
      }
    });

    setResultItems(items);
    setSelectedCardId(null);
  };

  // 文字变更时防抖触发
  useEffect(() => {
    if (autoGenerate) {
      const timer = setTimeout(() => {
        generateAllPinyin();
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [inputText, autoGenerate]);

  // 初始挂载渲染一次
  useEffect(() => {
    generateAllPinyin();
  }, []);

  // 点击外部收起选中的卡片
  useEffect(() => {
    const handleClickOutside = () => {
      setSelectedCardId(null);
    };
    window.addEventListener('click', handleClickOutside);
    return () => window.removeEventListener('click', handleClickOutside);
  }, []);

  // 改变指定卡片的拼调数
  const handleToneChange = (id: string, targetTone: number) => {
    setResultItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const updatedPinyin = replaceTone(item.pinyin, targetTone);
          return {
            ...item,
            pinyin: updatedPinyin,
            tone: targetTone,
          };
        }
        return item;
      })
    );
  };

  // 改变多音字的发音
  const handleAltChange = (id: string, newPinyin: string) => {
    setResultItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newTone = getCharTone(newPinyin);
          return {
            ...item,
            pinyin: newPinyin,
            tone: newTone,
          };
        }
        return item;
      })
    );
  };

  // 允许用户直接手动编辑修改拼音的方法
  const handlePinyinInputChange = (id: string, newPinyin: string) => {
    setResultItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newTone = getCharTone(newPinyin);
          return {
            ...item,
            pinyin: newPinyin,
            tone: newTone,
          };
        }
        return item;
      })
    );
  };

  // 预置范文点击载入
  const handleLoadPreset = (content: string) => {
    setInputText(content);
    // 强制立刻生成以获得好体验
    setTimeout(() => generateAllPinyin(), 10);
  };

  // 单独获取聚焦的卡片信息
  const selectedWordInfo = resultItems.find((i) => i.id === selectedCardId);

  // 按照换行符分子列表来进行断行排版渲染
  const renderedLines: PinyinWordItem[][] = [[]];
  resultItems.forEach((item) => {
    if (item.isNewline) {
      renderedLines.push([]);
    } else {
      renderedLines[renderedLines.length - 1].push(item);
    }
  });

  return (
    <div className="min-h-screen bg-[#F8F7F4] text-stone-900 flex flex-col antialiased font-sans">
      {/* 顶部通栏导航 */}
      <header className="border-b-2 border-stone-900 bg-[#F8F7F4] sticky top-0 z-50 px-6 py-6 transition-all">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-baseline md:justify-between gap-4">
          <div className="flex items-baseline gap-4">
            <h1 className="text-3xl font-bold font-serif italic tracking-tight text-stone-900 flex items-center gap-3">
              Pinyin Studio
            </h1>
            <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-widest">
              拼音生成与排版工具
            </span>
          </div>

          {/* 声调用色说明 */}
          <div className="bg-white border border-stone-200 rounded-none px-4 py-2.5 flex items-center gap-3.5 flex-wrap">
            <span className="text-[10px] font-bold text-stone-500 uppercase tracking-widest flex items-center gap-1">
              <Info className="w-3.5 h-3.5 text-stone-500" /> 色标定义
            </span>
            <div className="grid grid-cols-5 gap-1.5 text-xs">
              <span className="inline-flex items-center justify-center font-medium text-emerald-600 bg-emerald-50/50 px-2.5 py-0.5 rounded-none border border-emerald-200 text-[10px] tracking-wide uppercase">
                一声 (ā)
              </span>
              <span className="inline-flex items-center justify-center font-medium text-rose-500 bg-rose-50/50 px-2.5 py-0.5 rounded-none border border-rose-200 text-[10px] tracking-wide uppercase">
                二声 (á)
              </span>
              <span className="inline-flex items-center justify-center font-medium text-blue-600 bg-blue-50/50 px-2.5 py-0.5 rounded-none border border-blue-200 text-[10px] tracking-wide uppercase">
                三声 (ǎ)
              </span>
              <span className="inline-flex items-center justify-center font-medium text-stone-900 bg-stone-100 px-2.5 py-0.5 rounded-none border border-stone-350 text-[10px] tracking-wide uppercase">
                四声 (à)
              </span>
              <span className="inline-flex items-center justify-center font-medium text-stone-400 bg-stone-50 px-2.5 py-0.5 rounded-none border border-stone-200 text-[10px] tracking-wide uppercase">
                轻声 (a)
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* 主体工作区间 */}
      <main className="flex-grow max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* 左侧控制台 */}
        <section className="lg:col-span-4 flex flex-col gap-6">
          
          {/* 输入及设置区域 */}
          <div className="bg-white border border-stone-200 rounded-none p-5 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h2 className="text-[11px] font-semibold text-stone-500 uppercase tracking-widest flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-stone-600" />
                文本输入区域
              </h2>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setInputText('')}
                  className="p-1 text-stone-400 hover:text-stone-900 transition-colors"
                  title="清除内容"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="relative">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="在此输入中文句子、段落或诗词以生成对应的拼音卡片……"
                className="w-full h-36 p-4 text-sm border border-stone-200 rounded-none bg-[#FCFBF9] focus:outline-hidden focus:border-stone-900 focus:ring-0 resize-none leading-relaxed text-stone-800 font-sans"
              />
              <span className="absolute bottom-2.5 right-3 text-[9px] font-mono text-stone-400 select-none bg-stone-100 px-1.5 py-0.5 border border-stone-200 rounded-none">
                共 {inputText.length} 字
              </span>
            </div>

            {/* 实时/手动生成微调 */}
            <div className="flex items-center justify-between border-t border-stone-100 pt-3">
              <label className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-stone-500 select-none cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoGenerate}
                  onChange={(e) => setAutoGenerate(e.target.checked)}
                  className="rounded-none border-stone-300 text-stone-900 focus:ring-stone-900 w-4 h-4 cursor-pointer"
                />
                随打随译 (实时模式)
              </label>
              
              {!autoGenerate && (
                <button
                  onClick={generateAllPinyin}
                  className="px-4 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded-none text-xs font-semibold uppercase tracking-widest transition duration-150"
                >
                  立即生成
                </button>
              )}
            </div>
          </div>

          {/* 教纲格式设定 */}
          <div className="bg-white border border-stone-200 rounded-none p-5 flex flex-col gap-4">
            <h2 className="text-[11px] font-semibold text-stone-500 uppercase tracking-widest flex items-center gap-2">
              <Settings2 className="w-3.5 h-3.5 text-stone-600" />
              汉字字帖格式偏好
            </h2>

            <div className="grid grid-cols-2 gap-4">
              {/* 田字/米字选定 */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider flex items-center gap-1">
                  <Grid3X3 className="w-3 h-3" /> 识字格样式
                </span>
                <div className="flex p-0.5 bg-stone-100 rounded-none border border-stone-200">
                  {[
                    { id: 'mi', label: '米字' },
                    { id: 'tian', label: '田字' },
                    { id: 'kou', label: '口字' }
                  ].map((style) => (
                    <button
                      key={style.id}
                      onClick={() => setGridStyle(style.id as any)}
                      className={`flex-1 text-center py-1 text-xs font-medium rounded-none transition ${
                        gridStyle === style.id
                          ? 'bg-stone-900 text-white shadow-xs font-semibold'
                          : 'text-stone-500 hover:text-stone-800'
                      }`}
                    >
                      {style.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 格子基准颜色 */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider flex items-center gap-1">
                  <Palette className="w-3 h-3" /> 描线颜色
                </span>
                <div className="flex p-0.5 bg-stone-100 rounded-none border border-stone-200">
                  {[
                    { id: 'red', label: '红' },
                    { id: 'blue', label: '蓝' },
                    { id: 'green', label: '绿' },
                    { id: 'slate', label: '灰' }
                  ].map((color) => (
                    <button
                      key={color.id}
                      onClick={() => setLineColor(color.id as any)}
                      className={`flex-1 text-center py-1 text-xs font-medium rounded-none transition ${
                        lineColor === color.id
                          ? 'bg-stone-900 text-white font-semibold'
                          : 'text-stone-500 hover:text-stone-800'
                      }`}
                    >
                      {color.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

        </section>

        {/* 右侧主画面 (生成和编辑) */}
        <section className="lg:col-span-8 flex flex-col gap-6" ref={containerRef}>
          
          {/* 生成的卡片浏览版面 */}
          <div className="bg-white border border-stone-200 rounded-none p-6 flex-1 flex flex-col min-h-[440px]">
            <div className="flex items-center justify-between border-b border-stone-100 pb-4 mb-4 flex-wrap gap-2">
              <h2 className="text-[11px] font-semibold text-stone-500 uppercase tracking-widest flex items-center gap-2">
                <Layers className="w-3.5 h-3.5 text-stone-600" />
                拼音排版效果
                {resultItems.length > 0 && (
                  <span className="text-xs font-normal text-stone-400 font-mono tracking-normal lowercase">
                    ({resultItems.filter(i => i.isWord).length} 字)
                  </span>
                )}
              </h2>
              
              <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
                {/* 布局排版模式选择切块 */}
                <div className="flex border border-stone-200 p-0.5 bg-stone-100 text-[10px]">
                  <button
                    onClick={() => setLayoutMode('continuous')}
                    className={`px-2.5 py-1 font-medium transition cursor-pointer rounded-none ${
                      layoutMode === 'continuous'
                        ? 'bg-stone-900 text-white font-semibold'
                        : 'text-stone-500 hover:text-stone-800'
                    }`}
                  >
                    整篇排版 (连写)
                  </button>
                  <button
                    onClick={() => setLayoutMode('cards')}
                    className={`px-2.5 py-1 font-medium transition cursor-pointer rounded-none ${
                      layoutMode === 'cards'
                        ? 'bg-stone-900 text-white font-semibold'
                        : 'text-stone-500 hover:text-stone-800'
                    }`}
                  >
                    单字字帖 (卡片)
                  </button>
                </div>
                
                <span className="text-[9px] text-stone-400 font-sans tracking-wide select-none hidden sm:inline-block bg-stone-50 border border-stone-200 px-2 py-0.5">
                  点击单字校对读音
                </span>
              </div>
            </div>

            {/* 卡片或段落流渲染 */}
            {resultItems.length > 0 && (
              <div 
                onClick={() => {
                  const event = new CustomEvent('trigger-copy-pinyin-sheet', {
                    detail: { type: layoutMode === 'continuous' ? 'pinyin_image' : 'full_image' }
                  });
                  window.dispatchEvent(event);
                }}
                className="mb-4 bg-stone-900 hover:bg-stone-800 text-white p-3 flex flex-col sm:flex-row items-center justify-between gap-2.5 cursor-pointer border border-stone-950 transition duration-150 group select-none"
              >
                <div className="flex items-center gap-2 text-left">
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <span className="text-[11px] font-bold tracking-wider font-sans leading-normal">
                    📌 极速一键复制：直接点击「本提示栏」或「下方任何排版空白处」，即可瞬间复制超清无缝透明字帖！
                  </span>
                </div>
                <div className="flex items-center gap-1.5 bg-stone-800 text-stone-200 px-3 py-1 text-[10px] font-bold group-hover:bg-emerald-600 group-hover:text-white transition duration-150">
                  📋 立即点击复制
                </div>
              </div>
            )}

            {resultItems.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
                <div className="w-12 h-12 border border-dashed border-stone-400 text-stone-400 rounded-none flex items-center justify-center mb-4">
                  <Layers className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-serif italic text-stone-700">暂无生成的字贴内容</h3>
                <p className="text-xs text-stone-400 max-w-xs mt-1.5 leading-relaxed">
                  在控制台输入汉字或者直接点击左下角的快速教学示例，我们将在这里同步渲染标准的拼音。
                </p>
              </div>
            ) : layoutMode === 'continuous' ? (
              /* Continuous Prose Reading Mode */
              <div 
                className="flex-1 flex flex-col justify-between gap-10 select-none pb-4 cursor-pointer hover:bg-stone-50/10 p-2 border border-dashed border-transparent hover:border-stone-250 transition duration-150"
                onClick={(e) => {
                  const target = e.target as HTMLElement;
                  if (target.closest('button') || target.closest('[role="button"]') || target.closest('.hover-editor')) {
                    return;
                  }
                  const event = new CustomEvent('trigger-copy-pinyin-sheet', {
                    detail: { type: 'pinyin_image' }
                  });
                  window.dispatchEvent(event);
                }}
                title="点击此处空白即可一键复制全部纯拼音大图！"
              >
                {/* 汉字+拼音连贯上下对照排版区 */}
                <div className="flex flex-col gap-8 py-2">
                  {renderedLines.map((line, lineIdx) => {
                    if (line.length === 0) return null;
                    return (
                      <div 
                        key={`line-continuous-${lineIdx}`}
                        className="flex flex-wrap gap-x-1.5 sm:gap-x-2 gap-y-8 items-end leading-none py-1"
                      >
                        {line.map((item) => {
                          if (!item.isWord) {
                            return (
                              <span 
                                key={item.id} 
                                className="text-2xl font-serif text-stone-400 self-end px-1 pb-1"
                              >
                                {item.origin}
                              </span>
                            );
                          }
                          const isSelected = selectedCardId === item.id;
                          const pinyinColor = TONE_HEX_COLORS[item.tone] || '#1C1917';
                          const currentColors = LINE_COLORS[lineColor] || LINE_COLORS.red;
                          return (
                            <div
                              key={item.id}
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedCardId(item.id);
                              }}
                              className={`flex flex-col items-center group relative cursor-pointer p-1 transition-all duration-150 ${
                                isSelected 
                                  ? 'bg-stone-100 ring-1 ring-stone-900 shadow-md transform scale-110 z-20 mx-1' 
                                  : 'hover:bg-stone-50 border-b border-dashed border-transparent'
                              }`}
                            >
                              {/* 拼音 (在四线三格中，颜色根据声调有不同的颜色) */}
                              <div 
                                className="h-9 relative overflow-hidden flex items-center justify-center bg-white/50"
                                style={{ width: `${Math.max(56, item.pinyin.length * 16)}px` }}
                              >
                                <svg className="w-full h-full" viewBox="0 0 100 60" preserveAspectRatio="none">
                                  {/* 四条水平线 */}
                                  <line x1="0" y1="10" x2="100" y2="10" stroke={currentColors.outer} strokeWidth="1" />
                                  <line x1="0" y1="25" x2="100" y2="25" stroke={currentColors.inner} strokeWidth="0.8" strokeDasharray="3, 3" />
                                  <line x1="0" y1="40" x2="100" y2="40" stroke={currentColors.inner} strokeWidth="0.8" strokeDasharray="3, 3" />
                                  <line x1="0" y1="55" x2="100" y2="55" stroke={currentColors.outer} strokeWidth="1" />
                                  
                                  <text 
                                    x="50" 
                                    y="40" 
                                    textAnchor="middle" 
                                    fill={pinyinColor} 
                                    fontSize={getPinyinFontSize(item.pinyin.length)}
                                    fontWeight="bold"
                                    className="tracking-tight"
                                    style={{ fontFamily: 'var(--font-pinyin), "STXihei", "华文细黑", "Noto Sans SC", "GBpinyin", "GB Pinyin", "Andika", "Comfortaa", "Century Gothic", "Chalkboard SE", sans-serif' }}
                                  >
                                    {formatPinyinForDisplay(item.pinyin)}
                                  </text>
                                </svg>
                              </div>
                              {/* 汉字 (在下方) */}
                              <span 
                                className={`text-[23px] font-normal leading-none mt-2 ${
                                  isSelected ? 'text-stone-950 font-bold' : 'text-stone-850'
                                }`}
                                style={{ fontFamily: 'var(--font-kaiti)' }}
                              >
                                {item.origin}
                              </span>

                              {/* 极速悬浮编辑器 (仅在选中时展示) */}
                              <AnimatePresence>
                                {isSelected && (
                                  <motion.div 
                                    initial={{ opacity: 0, scale: 0.9, y: 15 }}
                                    animate={{ opacity: 1, scale: 1, y: 0 }}
                                    exit={{ opacity: 0, scale: 0.9, y: 10 }}
                                    transition={{ duration: 0.15 }}
                                    onClick={(e) => e.stopPropagation()} // 阻止向上传
                                    className="absolute bottom-full mb-3 bg-white border border-stone-900 shadow-xl p-3 w-56 flex flex-col gap-2.5 z-40 rounded-none text-left"
                                  >
                                    {/* 上箭头小尖尖 */}
                                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-1.5 w-3 h-3 bg-white border-r border-b border-stone-900 rotate-45 rounded-none" />

                                    <div className="flex flex-col gap-0.5 text-left text-xs text-stone-500 font-serif">
                                      <span className="text-[10px] uppercase tracking-wider text-stone-400 block font-sans font-semibold">声调校对</span>
                                      <span className="font-sans">调整「{item.origin}」的拼读音调:</span>
                                    </div>

                                    {/* 音调快捷按键 */}
                                    <div className="grid grid-cols-5 gap-1">
                                      {[1, 2, 3, 4, 0].map((t) => (
                                        <button
                                          key={t}
                                          type="button"
                                          onClick={() => handleToneChange(item.id, t)}
                                          className={`flex flex-col items-center justify-center py-1.5 border rounded-none text-xs font-medium transition-all duration-150 ${
                                            item.tone === t
                                              ? 'border-stone-900 bg-stone-900 text-white font-bold'
                                              : 'border-stone-200 hover:border-stone-400 bg-stone-50 hover:bg-stone-100 text-stone-700'
                                          }`}
                                          title={`变为:${t === 0 ? '轻声' : t + '声'}`}
                                        >
                                          <span 
                                            className="text-[14px] font-semibold"
                                            style={{ fontFamily: 'var(--font-pinyin), "STXihei", "华文细黑", "Noto Sans SC", "Andika", "Comfortaa", "Century Gothic", sans-serif' }}
                                          >
                                            {t === 1 && 'ā'}
                                            {t === 2 && 'á'}
                                            {t === 3 && 'ǎ'}
                                            {t === 4 && 'à'}
                                            {t === 0 && 'ɑ'}
                                          </span>
                                          <span className="text-[8px] text-stone-400 mt-0.5 font-normal tracking-wide">
                                            {t === 0 ? '轻' : `${t}声`}
                                          </span>
                                        </button>
                                      ))}
                                    </div>

                                    {/* 若为多音字，展示其他候选假定 */}
                                    {item.alternatives.length > 1 && (
                                      <div className="flex flex-col gap-1 mt-1 pt-1.5 border-t border-stone-100">
                                        <span className="text-[9px] text-stone-400 uppercase tracking-wider font-sans font-semibold">可选多音读音</span>
                                        <div className="flex flex-wrap gap-1">
                                          {item.alternatives.map((alt) => {
                                            return (
                                              <button
                                                key={alt}
                                                type="button"
                                                onClick={() => handleAltChange(item.id, alt)}
                                                className={`px-1.5 py-0.5 text-[10px] font-sans border rounded-none transition-all ${
                                                  item.pinyin === alt
                                                    ? 'border-stone-950 bg-stone-100 font-bold text-stone-950'
                                                    : 'border-stone-200 hover:border-stone-400 text-stone-600 hover:bg-stone-50'
                                                }`}
                                              >
                                                {formatPinyinForDisplay(alt)}
                                              </button>
                                            );
                                          })}
                                        </div>
                                      </div>
                                    )}

                                    {/* 手动可编辑拼音输入框 */}
                                    <div className="flex flex-col gap-1 mt-1 pt-2 border-t border-stone-100 text-left">
                                      <span className="text-[9px] text-stone-400 uppercase tracking-wider font-sans font-semibold">直接手动修改拼音</span>
                                      <input 
                                        type="text"
                                        value={item.pinyin}
                                        onChange={(e) => handlePinyinInputChange(item.id, e.target.value)}
                                        className="w-full px-2 py-1 text-xs border border-stone-200 text-stone-800 bg-[#FCFBF9] focus:bg-white focus:border-stone-900 focus:outline-hidden rounded-none font-sans"
                                        placeholder="在此直接输入修改拼音..."
                                      />
                                    </div>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })}
                </div>

                {/* 独立纯拼音整篇段落区 */}
                <div className="border-t border-stone-100 pt-6">
                  <div className="bg-[#FAF9F6] border border-stone-200 p-5 relative">
                    <span className="absolute top-2.5 right-3 text-[8.5px] uppercase tracking-wider font-semibold text-stone-400">
                      整篇拼音连写对照 (Pinyin Prose Reader)
                    </span>
                    <h3 className="text-[10px] uppercase font-bold text-stone-400 tracking-widest mb-3 flex items-center gap-1.5">
                      <Layers className="w-3 h-3 text-stone-400" /> 整篇拼音文本对照
                    </h3>
                    
                    {/* 段落纯拼音 */}
                    <div className="flex flex-col gap-4">
                      {renderedLines.map((line, lineIdx) => {
                        if (line.length === 0) return null;
                        return (
                          <div 
                            key={`pinyin-line-${lineIdx}`}
                            className="text-base sm:text-lg font-medium text-stone-805 tracking-wider leading-relaxed flex flex-wrap gap-x-2 gap-y-1 align-baseline"
                            style={{ fontFamily: 'var(--font-pinyin), "STXihei", "华文细黑", "Noto Sans SC", "GBpinyin", "GB Pinyin", "Andika", "Comfortaa", "Century Gothic", "Chalkboard SE", sans-serif' }}
                          >
                            {line.map((item, itemIdx) => {
                              if (!item.isWord) {
                                return (
                                  <span key={item.id || `text-${itemIdx}`} className="text-stone-400 select-text self-end">
                                    {item.origin}
                                  </span>
                                );
                              }
                              const isSelected = selectedCardId === item.id;
                              const pinyinColor = TONE_HEX_COLORS[item.tone] || '#1C1917';
                              return (
                                <span
                                  key={item.id}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedCardId(item.id);
                                  }}
                                  className={`relative cursor-pointer px-1.5 py-0.5 rounded-none transition-all duration-150 inline-block ${
                                    isSelected 
                                      ? 'bg-amber-100 ring-1 ring-amber-400 font-bold text-amber-950 scale-105 z-40' 
                                      : 'hover:bg-stone-200'
                                  }`}
                                  style={{ color: isSelected ? undefined : pinyinColor }}
                                  title={`点击单独微调/修改此字的拼音`}
                                >
                                  {formatPinyinForDisplay(item.pinyin)}

                                  {/* 段落内单独拼音悬浮编辑器 */}
                                  <AnimatePresence>
                                    {isSelected && (
                                      <span 
                                        onClick={(e) => e.stopPropagation()} // 阻止向上传
                                        className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-3 bg-white border border-stone-900 shadow-xl p-3 w-56 flex flex-col gap-2.5 z-50 rounded-none text-left font-sans text-xs normal-case cursor-default text-stone-850"
                                      >
                                        {/* 上箭头小尖尖 */}
                                        <span className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-1.5 w-3 h-3 bg-white border-r border-b border-stone-900 rotate-45 rounded-none" />

                                        <span className="flex flex-col gap-0.5 text-left text-neutral-500 font-serif">
                                          <span className="text-[10px] uppercase tracking-wider text-stone-400 block font-sans font-semibold">声调校对</span>
                                          <span className="font-sans">调整「{item.origin}」的拼读音调:</span>
                                        </span>

                                        {/* 音调快捷按键 */}
                                        <span className="grid grid-cols-5 gap-1">
                                          {[1, 2, 3, 4, 0].map((t) => (
                                            <button
                                              key={t}
                                              type="button"
                                              onClick={() => handleToneChange(item.id, t)}
                                              className={`flex flex-col items-center justify-center py-1.5 border rounded-none text-xs font-medium transition-all duration-150 ${
                                                item.tone === t
                                                  ? 'border-stone-900 bg-stone-900 text-white font-bold'
                                                  : 'border-stone-200 hover:border-stone-400 bg-stone-50 hover:bg-stone-100 text-stone-705'
                                              }`}
                                              title={`变为:${t === 0 ? '轻声' : t + '声'}`}
                                            >
                                              <span 
                                                className="text-[14px] font-semibold"
                                                style={{ fontFamily: 'var(--font-pinyin), "STXihei", "华文细黑", "Noto Sans SC", "Andika", "Comfortaa", "Century Gothic", sans-serif' }}
                                              >
                                                {t === 1 && 'ā'}
                                                {t === 2 && 'á'}
                                                {t === 3 && 'ǎ'}
                                                {t === 4 && 'à'}
                                                {t === 0 && 'ɑ'}
                                              </span>
                                              <span className="text-[8px] text-stone-400 mt-0.5 font-normal tracking-wide">
                                                {t === 0 ? '轻' : `${t}声`}
                                              </span>
                                            </button>
                                          ))}
                                        </span>

                                        {/* 若为多音字，展示其他候选假定 */}
                                        {item.alternatives.length > 1 && (
                                          <span className="flex flex-col gap-1 mt-1 pt-1.5 border-t border-stone-100">
                                            <span className="text-[9px] text-stone-400 uppercase tracking-wider font-sans font-semibold">可选多音读音</span>
                                            <span className="flex flex-wrap gap-1">
                                              {item.alternatives.map((alt) => {
                                                return (
                                                  <button
                                                    key={alt}
                                                    type="button"
                                                    onClick={() => handleAltChange(item.id, alt)}
                                                    className={`px-1.5 py-0.5 text-[10px] font-sans border rounded-none transition-all ${
                                                      item.pinyin === alt
                                                        ? 'border-stone-950 bg-stone-100 font-bold text-stone-950'
                                                        : 'border-stone-200 hover:border-stone-400 text-stone-605 hover:bg-stone-50'
                                                    }`}
                                                  >
                                                    {formatPinyinForDisplay(alt)}
                                                  </button>
                                                );
                                              })}
                                            </span>
                                          </span>
                                        )}

                                        {/* 手动可编辑拼音输入框 */}
                                        <span className="flex flex-col gap-1 mt-1 pt-2 border-t border-stone-100 text-left">
                                          <span className="text-[9px] text-stone-400 uppercase tracking-wider font-sans font-semibold">直接手动修改拼音</span>
                                          <input 
                                            type="text"
                                            value={item.pinyin}
                                            onChange={(e) => handlePinyinInputChange(item.id, e.target.value)}
                                            className="w-full px-2 py-1 text-xs border border-stone-200 text-stone-800 bg-[#FCFBF9] focus:bg-white focus:border-stone-900 focus:outline-hidden rounded-none font-sans"
                                            placeholder="在此直接输入修改拼音..."
                                          />
                                        </span>
                                      </span>
                                    )}
                                  </AnimatePresence>
                                </span>
                              );
                            })}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* Traditional Card Grid Mode */
              <div 
                className="flex-1 flex flex-col gap-8 select-none cursor-pointer hover:bg-stone-50/10 p-3 border border-dashed border-transparent hover:border-stone-250 transition duration-150 rounded"
                onClick={(e) => {
                  const target = e.target as HTMLElement;
                  if (target.closest('button') || target.closest('[role="button"]') || target.closest('.hover-editor')) {
                    return;
                  }
                  const event = new CustomEvent('trigger-copy-pinyin-sheet', {
                    detail: { type: 'full_image' }
                  });
                  window.dispatchEvent(event);
                }}
                title="直接点击排版任意空白处即可一键复制该拼音字帖大图！"
              >
                {renderedLines.map((line, lineIdx) => {
                  if (line.length === 0) return null;
                  return (
                    <div 
                      key={`line-${lineIdx}`}
                      className="flex flex-wrap gap-x-3.5 gap-y-6 items-end"
                    >
                      {line.map((item) => (
                        <PinyinCard
                          key={item.id}
                          item={item}
                          isSelected={selectedCardId === item.id}
                          onSelect={() => setSelectedCardId(item.id)}
                          onToneChange={(tone) => handleToneChange(item.id, tone)}
                          onAltChange={(pinyin) => handleAltChange(item.id, pinyin)}
                          onPinyinChange={(pinyin) => handlePinyinInputChange(item.id, pinyin)}
                          gridStyle={gridStyle}
                          lineColor={lineColor}
                        />
                      ))}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* 若有选中，在下方展示全尺寸的大屏编辑栏，大幅强化桌面端调音的用户体验 */}
          {selectedWordInfo && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="bg-white border-2 border-stone-900 rounded-none p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3.5">
                <span 
                  className="text-4xl font-normal text-stone-900 border border-stone-900 rounded-none bg-white w-14 h-14 flex items-center justify-center"
                  style={{ fontFamily: 'var(--font-kaiti)' }}
                >
                  {selectedWordInfo.origin}
                </span>
                <div>
                  <h4 className="text-[10px] font-semibold text-stone-400 uppercase tracking-widest font-sans">
                    校对栏
                  </h4>
                  <p className="text-xs text-stone-600 mt-1 font-sans">
                    实时读音：<span className="bg-stone-100 px-2 py-0.5 border border-stone-200 text-stone-900 font-bold text-[14px]" style={{ fontFamily: 'var(--font-pinyin)' }}>{formatPinyinForDisplay(selectedWordInfo.pinyin)}</span> 
                    &nbsp;({getToneName(selectedWordInfo.tone)})
                  </p>
                </div>
              </div>

              {/* 右侧操控区 */}
              <div className="flex flex-wrap gap-4 items-center">
                {/* 候选多音字选择 */}
                {selectedWordInfo.alternatives.length > 1 && (
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider">多音字音:</span>
                    <div className="flex gap-1">
                      {selectedWordInfo.alternatives.map((alt) => (
                        <button
                          key={alt}
                          onClick={() => handleAltChange(selectedWordInfo.id, alt)}
                          className={`px-2 py-1 text-xs border rounded-none font-sans transition ${
                            selectedWordInfo.pinyin === alt
                              ? 'bg-stone-900 border-stone-900 text-white font-bold'
                              : 'bg-white border-stone-200 text-stone-700 hover:border-stone-450 hover:bg-stone-50'
                          }`}
                        >
                          {alt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* 调音调按键 */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider">指定声调:</span>
                  <div className="flex gap-1 p-0.5 bg-stone-100 rounded-none border border-stone-200">
                    {[1, 2, 3, 4, 0].map((t) => (
                      <button
                        key={t}
                        onClick={() => handleToneChange(selectedWordInfo.id, t)}
                        className={`px-3 py-1 text-xs rounded-none font-medium transition ${
                          selectedWordInfo.tone === t
                            ? 'bg-stone-900 text-white font-semibold'
                            : 'text-stone-600 hover:text-stone-900'
                        }`}
                      >
                        {t === 0 ? '轻' : `${t}声`}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 直接键盘输入/修改拼音框 */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold text-stone-400 uppercase tracking-wider">手动编辑拼音:</span>
                  <input
                    type="text"
                    value={selectedWordInfo.pinyin}
                    onChange={(e) => handlePinyinInputChange(selectedWordInfo.id, e.target.value)}
                    className="px-2 py-1 text-xs border border-stone-900 focus:outline-hidden focus:ring-1 focus:ring-stone-900 rounded-none font-sans w-24 text-center font-bold text-stone-900 bg-[#FCFBF9]"
                    placeholder="输入读音..."
                  />
                </div>

                <button
                  onClick={() => setSelectedCardId(null)}
                  className="px-3 py-1 border border-stone-900 text-stone-900 hover:bg-stone-100 text-xs font-semibold uppercase tracking-widest rounded-none transition"
                >
                  确认
                </button>
              </div>
            </motion.div>
          )}

          {/* 隐藏的后台复制逻辑触发与通知框挂载 */}
          <CopyMenu items={resultItems} lineColor={lineColor} gridStyle={gridStyle} />

        </section>

      </main>

      {/* 极简底部 */}
      <footer className="border-t border-stone-200 py-8 bg-[#F8F7F4] text-center text-xs text-stone-400 font-serif">
        <p className="max-w-xl mx-auto italic leading-relaxed">小红书&copy;灯灯学姐在此</p>
      </footer>
    </div>
  );
}
