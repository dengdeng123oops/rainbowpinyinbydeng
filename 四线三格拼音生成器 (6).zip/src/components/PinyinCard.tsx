import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PinyinWordItem } from '../types';
import { getCharTone, formatPinyinForDisplay } from '../utils/pinyinUtils';

interface PinyinCardProps {
  key?: string;
  item: PinyinWordItem;
  isSelected: boolean;
  onSelect: () => void;
  onToneChange: (tone: number) => void;
  onAltChange: (pinyin: string) => void;
  onPinyinChange?: (pinyin: string) => void;
  gridStyle: 'mi' | 'tian' | 'kou';
  lineColor: 'red' | 'blue' | 'green' | 'slate';
}

const TONE_HEX_COLORS: Record<number, string> = {
  1: '#10B981', // 一声: 翡翠绿 (emerald-500)
  2: '#EF4444', // 二声: 胭脂红 (rose-500)
  3: '#3B82F6', // 三声: 霁蓝 (blue-500)
  4: '#171717', // 四声: 玄黑 (stone-950)
  0: '#9CA3AF', // 轻声: 苍灰 (gray-400)
};

const TONE_TAILWIND_CLASSES: Record<number, string> = {
  1: 'text-[#10B981] border-emerald-200 bg-emerald-50/30 hover:bg-emerald-50',
  2: 'text-[#EF4444] border-rose-200 bg-rose-50/30 hover:bg-rose-50',
  3: 'text-[#3B82F6] border-blue-200 bg-blue-50/30 hover:bg-blue-50',
  4: 'text-stone-900 border-stone-300 bg-stone-100 hover:bg-stone-200',
  0: 'text-stone-400 border-stone-200 bg-stone-50 hover:bg-stone-100',
};

// 四线三格颜色配置
const LINE_COLORS = {
  red: {
    outer: 'rgba(239, 68, 68, 0.45)',
    inner: 'rgba(239, 68, 68, 0.25)',
    gridBorder: 'border-rose-200 bg-rose-50/5',
    gridLines: 'rgba(239, 68, 68, 0.15)'
  },
  blue: {
    outer: 'rgba(59, 130, 246, 0.5)',
    inner: 'rgba(59, 130, 246, 0.3)',
    gridBorder: 'border-blue-200 bg-blue-50/5',
    gridLines: 'rgba(59, 130, 246, 0.15)'
  },
  green: {
    outer: 'rgba(16, 185, 129, 0.5)',
    inner: 'rgba(16, 185, 129, 0.3)',
    gridBorder: 'border-emerald-200 bg-emerald-50/5',
    gridLines: 'rgba(16, 185, 129, 0.15)'
  },
  slate: {
    outer: 'rgba(120, 113, 108, 0.45)', // stone-500
    inner: 'rgba(120, 113, 108, 0.25)',
    gridBorder: 'border-stone-300 bg-stone-50/5',
    gridLines: 'rgba(120, 113, 108, 0.15)'
  }
};

export default function PinyinCard({
  item,
  isSelected,
  onSelect,
  onToneChange,
  onAltChange,
  onPinyinChange,
  gridStyle,
  lineColor,
}: PinyinCardProps) {
  const currentColors = LINE_COLORS[lineColor];
  const pinyinColor = TONE_HEX_COLORS[item.tone];

  // 标点、非汉字，不需要拼音显示，直接单字居中展示
  if (!item.isWord) {
    return (
      <div 
        id={`card-${item.id}`}
        className="flex h-32 items-end justify-center pb-2 select-none"
      >
        <span className="text-3xl font-medium text-stone-400 px-2" style={{ fontFamily: 'var(--font-kaiti)' }}>
          {item.origin}
        </span>
      </div>
    );
  }

  const cardWidth = Math.max(96, item.pinyin.length * 24);

  return (
    <div 
      id={`card-${item.id}`}
      onClick={(e) => {
        e.stopPropagation();
        onSelect();
      }}
      className={`relative group flex flex-col items-center justify-between p-2.5 h-40 border transition-all duration-300 select-none bg-white cursor-pointer ${
        isSelected 
          ? 'ring-1 ring-stone-900 border-stone-900 shadow-md transform scale-105 z-10' 
          : 'border-stone-200 hover:border-stone-405 hover:-translate-y-0.5'
      }`}
      style={{ width: `${cardWidth}px` }}
    >
      {/* 1. 拼音拼写四线三格区 */}
      <div className="w-full h-[60px] relative overflow-hidden flex items-center justify-center">
        <svg className="w-full h-full animate-none" viewBox={`0 0 ${cardWidth} 60`}>
          {/* 四条水平线 */}
          {/* 第一线 (顶端) - 实线 */}
          <line x1="2" y1="10" x2={cardWidth - 2} y2="10" stroke={currentColors.outer} strokeWidth="1" />
          {/* 第二线 - 虚线 */}
          <line x1="2" y1="25" x2={cardWidth - 2} y2="25" stroke={currentColors.inner} strokeWidth="0.8" strokeDasharray="3, 3" />
          {/* 第三线 - 虚线 */}
          <line x1="2" y1="40" x2={cardWidth - 2} y2="40" stroke={currentColors.inner} strokeWidth="0.8" strokeDasharray="3, 3" />
          {/* 第四线 (底端) - 实线 */}
          <line x1="2" y1="55" x2={cardWidth - 2} y2="55" stroke={currentColors.outer} strokeWidth="1" />
          
          {/* 拼音文本 - 引入固定 fontSize=30 与 y=40 坐标方案，拼音主体精准占据第二格(25~40间，高度15px)，英文字母完全落于线上。声调标符自动完美居于第一格中部(中间核心区17.5px) */}
          <text 
            x={cardWidth / 2} 
            y="40" 
            textAnchor="middle" 
            fill={pinyinColor} 
            fontSize="30"
            fontWeight="bold"
            className="tracking-wide"
            style={{ fontFamily: 'var(--font-pinyin), "STXihei", "华文细黑", "Noto Sans SC", "GBpinyin", "GB Pinyin", "Andika", "Comfortaa", "Century Gothic", "Chalkboard SE", sans-serif' }}
          >
            {formatPinyinForDisplay(item.pinyin)}
          </text>
        </svg>
      </div>

      {/* 2. 汉字田字格或米字格区 */}
      <div className={`relative w-[76px] h-[76px] flex items-center justify-center border-2 ${currentColors.gridBorder} transition-colors duration-300`}>
        <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 76 76">
          {/* 田字格：横、竖虚线 */}
          {gridStyle !== 'kou' && (
            <>
              <line x1="0" y1="38" x2="76" y2="38" stroke={currentColors.gridLines} strokeWidth="0.8" strokeDasharray="2, 2" />
              <line x1="38" y1="0" x2="38" y2="76" stroke={currentColors.gridLines} strokeWidth="0.8" strokeDasharray="2, 2" />
            </>
          )}
          {/* 米字格：加上对角线 */}
          {gridStyle === 'mi' && (
            <>
              <line x1="0" y1="0" x2="76" y2="76" stroke={currentColors.gridLines} strokeWidth="0.5" strokeDasharray="3, 3" />
              <line x1="76" y1="0" x2="0" y2="76" stroke={currentColors.gridLines} strokeWidth="0.5" strokeDasharray="3, 3" />
            </>
          )}
        </svg>
        
        {/* 加大单个汉字并使用标准手写楷书字体 */}
        <span 
          className="relative z-10 text-[54px] font-bold text-stone-900 leading-none"
          style={{ fontFamily: 'var(--font-kaiti)', lineHeight: '1' }}
        >
          {item.origin}
        </span>
      </div>

      {/* 声调角标 (仅未选中且 hover 时，提供音调反馈) */}
      {!isSelected && (
        <span className="absolute bottom-1 right-2 text-[9px] font-sans uppercase tracking-wider text-stone-400 opacity-0 group-hover:opacity-100 transition-opacity">
          音调:{item.tone}
        </span>
      )}

      {/* 3. 极速悬浮编辑器 (仅在选中时展示) */}
      <AnimatePresence>
        {isSelected && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            transition={{ duration: 0.15 }}
            onClick={(e) => e.stopPropagation()} // 阻止向上传给卡片
            className="absolute bottom-full mb-3 bg-white border border-stone-900 shadow-lg p-3 w-56 flex flex-col gap-2.5 z-40 rounded-none"
          >
            {/* 上箭头小尖尖 */}
            <div className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-1.5 w-3 h-3 bg-white border-r border-b border-stone-900 rotate-45 rounded-none" />

            <div className="flex flex-col gap-0.5 text-left text-xs text-stone-500 font-serif">
              <span className="text-[10px] uppercase tracking-wider text-stone-400 block font-sans">声调校对</span>
              <span className="font-sans">调整「{item.origin}」的拼读音调:</span>
            </div>

            {/* 音调快捷按键 */}
            <div className="grid grid-cols-5 gap-1">
              {[1, 2, 3, 4, 0].map((t) => (
                <button
                  key={t}
                  onClick={() => onToneChange(t)}
                  className={`flex flex-col items-center justify-center py-1.5 border rounded-none text-xs font-medium transition-all duration-150 ${
                    item.tone === t
                      ? 'border-stone-900 bg-stone-900 text-white font-bold'
                      : 'border-stone-200 hover:border-stone-400 bg-stone-50 hover:bg-stone-100 text-stone-700'
                  }`}
                  title={`变为:${t === 0 ? '轻声' : t + '声'}`}
                >
                  <span 
                    className="text-[14px] font-semibold"
                    style={{ fontFamily: 'var(--font-pinyin), "STXihei", "华文细黑", "Noto Sans SC", "Andika", "Comfortaa", "Century Gothic", sans-serif' }}
                  >
                    {t === 1 && 'ā'}
                    {t === 2 && 'á'}
                    {t === 3 && 'ǎ'}
                    {t === 4 && 'à'}
                    {t === 0 && 'ɑ'}
                  </span>
                  <span className="text-[8px] text-stone-400 mt-0.5 font-normal tracking-wide">
                    {t === 0 ? '轻' : `${t}声`}
                  </span>
                </button>
              ))}
            </div>

            {/* 若为多音字，展示其他候选假定 */}
            {item.alternatives.length > 1 && (
              <div className="flex flex-col gap-1 mt-1 pt-1.5 border-t border-stone-100">
                <span className="text-[9px] text-stone-400 uppercase tracking-wider font-sans font-medium text-left">可选多音读音</span>
                <div className="flex flex-wrap gap-1">
                  {item.alternatives.map((alt) => {
                    return (
                      <button
                        key={alt}
                        onClick={() => onAltChange(alt)}
                        className={`px-1.5 py-0.5 text-[10px] font-sans border rounded-none transition-all ${
                          item.pinyin === alt
                            ? 'border-stone-950 bg-stone-100 font-bold text-stone-950'
                            : 'border-stone-200 hover:border-stone-400 text-stone-600 hover:bg-stone-50'
                        }`}
                      >
                        {formatPinyinForDisplay(alt)}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 手动可编辑拼音输入框 */}
            <div className="flex flex-col gap-1 mt-1 pt-2 border-t border-stone-100 text-left">
              <span className="text-[9px] text-stone-400 uppercase tracking-wider font-sans font-medium">直接手动修改拼音</span>
              <input 
                type="text"
                value={item.pinyin}
                onChange={(e) => onPinyinChange && onPinyinChange(e.target.value)}
                className="w-full px-2 py-1 text-xs border border-stone-200 text-stone-800 bg-[#FCFBF9] focus:bg-white focus:border-stone-900 focus:outline-hidden rounded-none font-sans"
                placeholder="在此直接输入修改拼音..."
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
