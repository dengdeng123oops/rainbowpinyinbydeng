import React, { useState, useRef } from 'react';
import { Check, Clipboard, Image as ImageIcon, Layers } from 'lucide-react';
import { PinyinWordItem } from '../types';
import { toBlob } from 'html-to-image';
import { formatPinyinForDisplay } from '../utils/pinyinUtils';

interface CopyMenuProps {
  items: PinyinWordItem[];
  lineColor: 'red' | 'blue' | 'green' | 'slate';
  gridStyle: 'mi' | 'tian' | 'kou';
}

const TONE_HEX_COLORS: Record<number, string> = {
  1: '#10B981', // 一声: 翡翠绿 (emerald-500)
  2: '#EF4444', // 二声: 胭脂红 (rose-500)
  3: '#3B82F6', // 三声: 霁蓝 (blue-500)
  4: '#171717', // 四声: 玄黑 (stone-950)
  0: '#9CA3AF', // 轻声: 苍灰 (gray-400)
};

const LINE_COLORS = {
  red: {
    outer: 'rgba(239, 68, 68, 0.45)',
    inner: 'rgba(239, 68, 68, 0.25)',
    gridBorder: '#FECDD3', // rose-200
    gridBg: 'transparent', 
    gridLines: 'rgba(239, 68, 68, 0.2)',
    borderHex: '#EF4444',
  },
  blue: {
    outer: 'rgba(59, 130, 246, 0.5)',
    inner: 'rgba(59, 130, 246, 0.3)',
    gridBorder: '#BFDBFE', // blue-200
    gridBg: 'transparent', 
    gridLines: 'rgba(59, 130, 246, 0.2)',
    borderHex: '#3B82F6',
  },
  green: {
    outer: 'rgba(16, 185, 129, 0.5)',
    inner: 'rgba(16, 185, 129, 0.3)',
    gridBorder: '#A7F3D0', // emerald-200
    gridBg: 'transparent', 
    gridLines: 'rgba(16, 185, 129, 0.2)',
    borderHex: '#10B981',
  },
  slate: {
    outer: 'rgba(120, 113, 108, 0.45)',
    inner: 'rgba(120, 113, 108, 0.25)',
    gridBorder: '#D6D3D1', // stone-300
    gridBg: 'transparent', 
    gridLines: 'rgba(120, 113, 108, 0.2)',
    borderHex: '#78716C',
  }
};

export default function CopyMenu({ items, lineColor, gridStyle }: CopyMenuProps) {
  const [copiedType, setCopiedType] = useState<'pinyin_image' | 'full_image' | null>(null);
  const [generatingType, setGeneratingType] = useState<'pinyin_image' | 'full_image' | null>(null);
  const [transparentCardBg, setTransparentCardBg] = useState<boolean>(true);
  
  // Custom interactive toasts for seamless user feedback
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [isError, setIsError] = useState(false);

  const triggerToast = (message: string, error = false) => {
    setToastMessage(message);
    setIsError(error);
    setShowToast(true);
    const timer = setTimeout(() => {
      setShowToast(false);
    }, 4000);
    return () => clearTimeout(timer);
  };

  const pinyinOnlyRef = useRef<HTMLDivElement>(null);
  const pinyinWithGridRef = useRef<HTMLDivElement>(null);

  // Custom event listener allowing triggering from App.tsx or direct tıklamalar (direct clicking of generated outputs)
  React.useEffect(() => {
    const handleTrigger = (e: Event) => {
      const customEvent = e as CustomEvent<{ type?: 'pinyin_image' | 'full_image' }>;
      const targetType = customEvent.detail?.type || 'full_image';
      handleCopyAsTransparentImage(targetType);
    };
    window.addEventListener('trigger-copy-pinyin-sheet', handleTrigger);
    return () => {
      window.removeEventListener('trigger-copy-pinyin-sheet', handleTrigger);
    };
  }, [items, lineColor, gridStyle, transparentCardBg]);

  // Helper method to split items by newline
  const getLines = () => {
    const lines: PinyinWordItem[][] = [[]];
    items.forEach((item) => {
      if (item.isNewline) {
        lines.push([]);
      } else {
        lines[lines.length - 1].push(item);
      }
    });
    return lines.filter(line => line.length > 0);
  };

  const handleCopyAsTransparentImage = async (type: 'pinyin_image' | 'full_image') => {
    const targetRef = type === 'pinyin_image' ? pinyinOnlyRef : pinyinWithGridRef;
    if (!targetRef.current) return;

    setGeneratingType(type);
    triggerToast(type === 'pinyin_image' ? '正在为您排版渲染标准无背景拼音大图...' : '正在为您排版生成米字田字格标准拼音字帖...');

    try {
      // Create high resolution transparent PNG image cutout
      const blob = await toBlob(targetRef.current, {
        cacheBust: true,
        backgroundColor: 'rgba(0,0,0,0)', // Completely transparent background cutout (无背景抠图)
        pixelRatio: 2.8, // Enhanced high DPI resolution for screen and printable uses
      });

      if (blob) {
        try {
          const item = new ClipboardItem({ [blob.type]: blob });
          await navigator.clipboard.write([item]);
          setCopiedType(type);
          triggerToast('✨ 复制成功！已写入剪贴板（标准无缝透明抠图，可直接在 PPT/Word 粘贴）');
        } catch (clipErr) {
          console.warn('Advanced clipboard execution restricted. Initiating clean PNG download backup:', clipErr);
          // Auto-download fallback in sandboxed env
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          const label = type === 'pinyin_image' ? '全部拼音内容_无背景抠图' : '拼音汉字田字格_无背景抠图';
          link.download = `拼音字帖_${label}_${Date.now()}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
          setCopiedType(type);
          triggerToast('📥 剪贴板受浏览器安全限制，已为您极速下载超清透明 PNG 图片！');
        }
      }
    } catch (err) {
      console.error('Critical failure during lossless image rendering capture:', err);
      triggerToast('❌ 排版生成失败，请确认输入内容后重试。', true);
    } finally {
      setGeneratingType(null);
      setTimeout(() => setCopiedType(null), 3000);
    }
  };

  const hasWords = items.some((i) => i.isWord);
  const lines = getLines();

  return (
    <div className="relative w-0 h-0 overflow-visible" id="copy-menu-wrapper">
      {/* =========================================================================
          OFF-SCREEN HIDDEN RENDERERS FOR PERFECT TRANSPARENT IMAGE GENERATION 
          ========================================================================= */}
      <div style={{ position: 'absolute', left: '-9999px', top: '-9999px', zIndex: -9999, pointerEvents: 'none' }}>
        
        {/* RENDERER 1: 连写模式 (Continuous Prose Reading Layout) - 对应网页端 2x 结构 */}
        <div 
          ref={pinyinOnlyRef} 
          className="p-16 select-none flex flex-col gap-14 bg-transparent"
          style={{ backgroundColor: 'transparent', width: 'max-content', maxWidth: '1400px' }}
        >
          <style dangerouslySetInnerHTML={{ __html: `
            @font-face {
              font-family: 'GBpinyin';
              src: url('https://db.onlinewebfonts.com/t/3d6ca7a544a86f9ee5bcca5fe90209ab.woff2') format('woff2'),
                   url('https://db.onlinewebfonts.com/t/3d6ca7a544a86f9ee5bcca5fe90209ab.woff') format('woff'),
                   url('https://db.onlinewebfonts.com/t/3d6ca7a544a86f9ee5bcca5fe90209ab.ttf') format('truetype');
              font-display: swap;
            }
            :root {
              --font-pinyin: "STXihei", "华文细黑", "Noto Sans SC", "GBpinyin", "GB Pinyin", "汉仪拼音", "方正拼音", "Andika", "Comfortaa", "Century Gothic", "Chalkboard SE", sans-serif;
            }
            .pinyin-font-render {
              font-family: var(--font-pinyin), "STXihei", "华文细黑", "Noto Sans SC", "GBpinyin", "GB Pinyin", "汉仪拼音", "方正拼音", "Andika", "Comfortaa", "Century Gothic", "Chalkboard SE", sans-serif !important;
            }
          `}} />
          <div className="flex flex-col gap-14 py-2">
            {lines.map((line, lineIdx) => (
              <div 
                key={`pinyin-only-line-${lineIdx}`} 
                className="flex flex-wrap gap-x-4 gap-y-16 items-end leading-none py-1"
              >
                {line.map((item) => {
                  if (!item.isWord) {
                    return (
                      <span 
                        key={item.id} 
                        className="text-4xl font-serif text-stone-450 self-end px-2 pb-2 font-bold"
                      >
                        {item.origin}
                      </span>
                    );
                  }

                  const pinyinColor = TONE_HEX_COLORS[item.tone] || '#1C1917';
                  const colors = LINE_COLORS[lineColor] || LINE_COLORS.red;
                  const proseWidth = Math.max(112, item.pinyin.length * 32);

                  return (
                    <div
                      key={item.id}
                      className="flex flex-col items-center p-2 relative bg-transparent"
                    >
                      {/* 拼音 (2x 放大渲染，动态调整长度防止拥挤溢出) */}
                      <div 
                        className="h-18 relative overflow-hidden flex items-center justify-center bg-transparent"
                        style={{ width: `${proseWidth}px` }}
                      >
                        <svg className="w-full h-full bg-transparent animate-none" viewBox={`0 0 ${proseWidth} 60`}>
                          <line x1="2" y1="10" x2={proseWidth - 2} y2="10" stroke={colors.outer} strokeWidth="1" />
                          <line x1="2" y1="25" x2={proseWidth - 2} y2="25" stroke={colors.inner} strokeWidth="0.8" strokeDasharray="3, 3" />
                          <line x1="2" y1="40" x2={proseWidth - 2} y2="40" stroke={colors.inner} strokeWidth="0.8" strokeDasharray="3, 3" />
                          <line x1="2" y1="55" x2={proseWidth - 2} y2="55" stroke={colors.outer} strokeWidth="1" />
                          
                          <text
                            x={proseWidth / 2}
                            y="40"
                            textAnchor="middle"
                            fill={pinyinColor}
                            fontSize="30"
                            fontWeight="bold"
                            className="tracking-wide pinyin-font-render"
                            style={{ fontFamily: 'var(--font-pinyin), "STXihei", "华文细黑", "GBpinyin", "GB Pinyin", "汉仪拼音", "方正拼音", "Andika", "Comfortaa", "Century Gothic", "Chalkboard SE", sans-serif' }}
                          >
                            {formatPinyinForDisplay(item.pinyin)}
                          </text>
                        </svg>
                      </div>
                      {/* 汉字 (text-[46px] leading-none mt-4 text-stone-850) */}
                      <span 
                        className="text-[46px] font-normal leading-none mt-4 text-stone-850"
                        style={{ fontFamily: 'var(--font-kaiti)' }}
                      >
                        {item.origin}
                      </span>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        {/* RENDERER 2: 卡片网格二模 (Traditional Card Grid Layout) - 与网页端卡片 2x 放大结构一致 */}
        <div 
          ref={pinyinWithGridRef} 
          className="p-16 select-none flex flex-col gap-14 bg-transparent"
          style={{ backgroundColor: 'transparent', width: 'max-content', maxWidth: '1400px' }}
        >
          <style dangerouslySetInnerHTML={{ __html: `
            @font-face {
              font-family: 'GBpinyin';
              src: url('https://db.onlinewebfonts.com/t/3d6ca7a544a86f9ee5bcca5fe90209ab.woff2') format('woff2'),
                   url('https://db.onlinewebfonts.com/t/3d6ca7a544a86f9ee5bcca5fe90209ab.woff') format('woff'),
                   url('https://db.onlinewebfonts.com/t/3d6ca7a544a86f9ee5bcca5fe90209ab.ttf') format('truetype');
              font-display: swap;
            }
            :root {
              --font-pinyin: "STXihei", "华文细黑", "Noto Sans SC", "GBpinyin", "GB Pinyin", "汉仪拼音", "方正拼音", "Andika", "Comfortaa", "Century Gothic", "Chalkboard SE", sans-serif;
            }
            .pinyin-font-render {
              font-family: var(--font-pinyin), "STXihei", "华文细黑", "Noto Sans SC", "GBpinyin", "GB Pinyin", "汉仪拼音", "方正拼音", "Andika", "Comfortaa", "Century Gothic", "Chalkboard SE", sans-serif !important;
            }
          `}} />
          {lines.map((line, lineIdx) => (
            <div key={`pinyin-grid-line-${lineIdx}`} className="flex flex-wrap gap-x-7 gap-y-12 items-end leading-none">
              {line.map((item) => {
                if (!item.isWord) {
                  return (
                    <div 
                      key={item.id} 
                      className="flex flex-col items-center justify-end select-none bg-transparent"
                      style={{ width: '192px', height: '320px', paddingBottom: '40px' }}
                    >
                      <span className="text-6xl font-serif text-stone-700 px-2 font-bold">
                        {item.origin}
                      </span>
                    </div>
                  );
                }

                const pinyinColor = TONE_HEX_COLORS[item.tone] || '#171717';
                const colors = LINE_COLORS[lineColor] || LINE_COLORS.red;
                const cardWidthTarget = Math.max(192, item.pinyin.length * 48);

                return (
                  <div
                    key={item.id}
                    className={`flex flex-col items-center justify-between p-5 transition-all ${
                      transparentCardBg
                        ? 'bg-transparent border border-transparent'
                        : 'border border-stone-200 bg-white shadow-xs'
                    }`}
                    style={{ width: `${cardWidthTarget}px`, height: '320px' }}
                  >
                    {/* 拼音 (四线三格) - height 120px 2x 尺寸，使用 2x 坐标实现完美饱满效果 */}
                    <div className="w-full h-[120px] relative overflow-hidden flex items-center justify-center bg-transparent">
                      <svg className="w-full h-full bg-transparent animate-none" viewBox={`0 0 ${cardWidthTarget} 120`}>
                        <line x1="4" y1="20" x2={cardWidthTarget - 4} y2="20" stroke={colors.outer} strokeWidth="1.6" />
                        <line x1="4" y1="50" x2={cardWidthTarget - 4} y2="50" stroke={colors.inner} strokeWidth="1.2" strokeDasharray="6, 6" />
                        <line x1="4" y1="80" x2={cardWidthTarget - 4} y2="80" stroke={colors.inner} strokeWidth="1.2" strokeDasharray="6, 6" />
                        <line x1="4" y1="110" x2={cardWidthTarget - 4} y2="110" stroke={colors.outer} strokeWidth="1.6" />
                        <text
                          x={cardWidthTarget / 2}
                          y="80"
                          textAnchor="middle"
                          fill={pinyinColor}
                          fontSize="60"
                          fontWeight="bold"
                          className="pinyin-font-render animate-none tracking-wide"
                          style={{ fontFamily: 'var(--font-pinyin), "STXihei", "华文细黑", "GBpinyin", "GB Pinyin", "汉仪拼音", "方正拼音", "Andika", "Comfortaa", "Century Gothic", "Chalkboard SE", sans-serif' }}
                        >
                          {formatPinyinForDisplay(item.pinyin)}
                        </text>
                      </svg>
                    </div>

                    {/* 汉字格 (w-[152px] h-[152px] 2x 尺寸，完美充满) */}
                    <div
                      className="relative w-[152px] h-[152px] flex items-center justify-center border-2"
                      style={{
                        borderColor: colors.gridBorder,
                        backgroundColor: 'transparent',
                      }}
                    >
                      <svg className="absolute inset-0 w-full h-full pointer-events-none bg-transparent" viewBox="0 0 152 152">
                        {gridStyle !== 'kou' && (
                          <>
                            <line x1="0" y1="76" x2="152" y2="76" stroke={colors.gridLines} strokeWidth="0.8" strokeDasharray="2, 2" />
                            <line x1="76" y1="0" x2="76" y2="152" stroke={colors.gridLines} strokeWidth="0.8" strokeDasharray="2, 2" />
                          </>
                        )}
                        {gridStyle === 'mi' && (
                          <>
                            <line x1="0" y1="0" x2="152" y2="152" stroke={colors.gridLines} strokeWidth="0.5" strokeDasharray="3, 3" />
                            <line x1="152" y1="0" x2="0" y2="152" stroke={colors.gridLines} strokeWidth="0.5" strokeDasharray="3, 3" />
                          </>
                        )}
                      </svg>
                      <span 
                        className="relative z-10 text-[108px] font-bold text-stone-900 leading-none" 
                        style={{ fontFamily: 'var(--font-kaiti)', lineHeight: '1' }}
                      >
                        {item.origin}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>

      </div>

      {showToast && (
        <div 
          className={`fixed bottom-8 left-1/2 transform -translate-x-1/2 z-[100] px-6 py-3 shadow-2xl flex items-center gap-2.5 border-2 text-xs font-bold font-sans tracking-wide transition-all duration-350 animate-bounce select-none ${
            isError ? 'bg-rose-50 border-rose-900 text-rose-900' : 'bg-white border-stone-950 text-stone-950'
          }`}
          style={{ boxShadow: '0 20px 25px -5px rgba(0,0,0,0.15), 0 8px 10px -6px rgba(0,0,0,0.15)' }}
        >
          {isError ? (
            <span>⚠️</span>
          ) : (
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          )}
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
