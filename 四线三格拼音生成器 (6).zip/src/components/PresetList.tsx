import React from 'react';
import { PresetItem } from '../types';

interface PresetListProps {
  onSelectPreset: (content: string) => void;
}

const PRESETS: PresetItem[] = [
  {
    title: '静夜思 (李白)',
    category: '经典古诗',
    content: '床前明月光，疑是地上霜。\n举头望明月，低头思故乡。'
  },
  {
    title: '春晓 (孟浩然)',
    category: '经典古诗',
    content: '春眠不觉晓，处处闻啼鸟。\n夜来风雨声，花落知多少。'
  },
  {
    title: '吃葡萄 (经典绕口令)',
    category: '趣味绕口令',
    content: '吃葡萄不吐葡萄皮，\n不吃葡萄倒吐葡萄皮。'
  },
  {
    title: '八百标兵 (字音训练)',
    category: '趣味绕口令',
    content: '八百标兵奔北坡，\n炮兵并排北边跑。'
  },
  {
    title: '多音字对照 (一字多音)',
    category: '拼音教学',
    content: '得到这数，得数得对，\n你可省省心，别去省城。'
  },
  {
    title: '幼教基础 (日常口语)',
    category: '拼音教学',
    content: '爸爸、妈妈，我爱我的家！\n太阳下山了，月亮升起来。'
  }
];

export default function PresetList({ onSelectPreset }: PresetListProps) {
  // 分组 presets
  const categories = Array.from(new Set(PRESETS.map(p => p.category)));

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h3 className="text-[11px] font-semibold text-stone-400 uppercase tracking-widest">
          快速示例教学载入
        </h3>
      </div>
      
      <div className="flex flex-col gap-4">
        {categories.map((category) => (
          <div key={category} className="flex flex-col gap-1.5">
            <span className="text-[10px] uppercase font-semibold text-stone-500 tracking-widest bg-stone-100 px-1.5 py-0.5 rounded-none w-max border border-stone-200">
              {category}
            </span>
            <div className="grid grid-cols-2 gap-2">
              {PRESETS.filter(p => p.category === category).map((preset) => (
                <button
                  key={preset.title}
                  onClick={() => onSelectPreset(preset.content)}
                  className="text-left text-xs text-stone-700 bg-white border border-stone-200 hover:border-stone-600 hover:bg-stone-50/50 p-2.5 rounded-none transition duration-150 inline-flex flex-col justify-between"
                >
                  <span className="font-serif font-semibold text-stone-800 mb-0.5">{preset.title}</span>
                  <span className="text-[10px] text-stone-400 truncate max-w-full">
                    {preset.content.replace(/\n/g, ' ')}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
